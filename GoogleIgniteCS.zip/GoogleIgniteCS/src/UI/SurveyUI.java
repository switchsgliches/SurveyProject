package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Student;

import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class SurveyUI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					SurveyUI frame = new SurveyUI();
					frame.setVisible(true);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public SurveyUI() {
		setTitle("Ignite CS Survey");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 618, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel UserNamelabel = new JLabel(""+Student.getStudentUserName());
		UserNamelabel.setBounds(15, 16, 69, 20);
		contentPane.add(UserNamelabel);
		
		JLabel lblQuestion = new JLabel("Question 1: How much did you learn from this event?");
		lblQuestion.setBounds(15, 52, 403, 20);
		contentPane.add(lblQuestion);
		
		JComboBox Q1comboBox = new JComboBox();
		Q1comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "None", "A little", "Average", "Quite a bit", "A lot"}));
		Q1comboBox.setBounds(453, 49, 128, 26);
		contentPane.add(Q1comboBox);
		
		JLabel lblQuestion2 = new JLabel("Question 2:How much did you enjoy this event? ");
		lblQuestion2.setBounds(15, 88, 403, 20);
		contentPane.add(lblQuestion2);
		
		JComboBox Q2comboBox = new JComboBox();
		Q2comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "None", "A little", "Average", "Quite a bit", "A lot"}));
		Q2comboBox.setBounds(453, 85, 128, 26);
		contentPane.add(Q2comboBox);
		
		JLabel lblQuestion3 = new JLabel("Question 3: Rate how much you liked each event: Event 1: ");
		lblQuestion3.setBounds(15, 124, 403, 20);
		contentPane.add(lblQuestion3);
		
		JComboBox Q3comboBox = new JComboBox();
		Q3comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Strongly dislike", "Dislike", "Neutural", "Like", "Strongly Like"}));
		Q3comboBox.setBounds(453,121, 128, 26);
		contentPane.add(Q3comboBox);
		
		JLabel lblQuestion4 = new JLabel("Question4: Event two: ");
		lblQuestion4.setBounds(15, 160, 403, 20);
		contentPane.add(lblQuestion4);
		
		JComboBox Q4comboBox = new JComboBox();
		Q4comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Strongly dislike", "Dislike", "Neutural", "Like", "Strongly Like"}));
		Q4comboBox.setBounds(453,160, 128, 26);
		contentPane.add(Q4comboBox);
		
		JLabel lblQuestion5 = new JLabel("Question5: Event three:");
		lblQuestion5.setBounds(15, 196, 403, 20);
		contentPane.add(lblQuestion5);
		
		JComboBox Q5comboBox = new JComboBox();
		Q5comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Strongly dislike", "Dislike", "Neutural", "Like", "Strongly Like"}));
		Q5comboBox.setBounds(453,196, 128, 26);
		contentPane.add(Q5comboBox);
		
		JLabel lblQuestion6 = new JLabel("Question6: Event four:");
		lblQuestion6.setBounds(15, 232, 403, 20);
		contentPane.add(lblQuestion6);
		
		JComboBox Q6comboBox = new JComboBox();
		Q6comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Strongly dislike", "Dislike", "Neutural", "Like", "Strongly Like"}));
		Q6comboBox.setBounds(453,232, 128, 26);
		contentPane.add(Q6comboBox);
		
		JLabel lblQuestion7 = new JLabel("Question 7: How likely are you to participate in this event again? ");
		lblQuestion7.setBounds(15, 268, 403, 20);
		contentPane.add(lblQuestion7);
		
		JComboBox Q7comboBox = new JComboBox();
		Q7comboBox.setModel(new DefaultComboBoxModel(new String[] {"","None", "A little", "Average", "Quite a bit", "A lot"}));
		Q7comboBox.setBounds(453,268, 128, 26);
		contentPane.add(Q7comboBox);
		
		JLabel lblQuestion8 = new JLabel("Question8: Hoe hard was it to understand each subject from the events? Event one: ");
		lblQuestion8.setBounds(15, 304, 403, 20);
		contentPane.add(lblQuestion8);
		
		JComboBox Q8comboBox = new JComboBox();
		Q8comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Very Hard", "Hard", "Neutural", "Easy", "Very Easy"}));
		Q8comboBox.setBounds(453,304, 128, 26);
		contentPane.add(Q8comboBox);
		
		JLabel lblQuestion9 = new JLabel("Question 9: Event two:");
		lblQuestion9.setBounds(15, 340, 403, 20);
		contentPane.add(lblQuestion9);
		
		JComboBox Q9comboBox = new JComboBox();
		Q9comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Very Hard", "Hard", "Neutural", "Easy", "Very Easy"}));
		Q9comboBox.setBounds(453,340, 128, 26);
		contentPane.add(Q9comboBox);
		
		JLabel lblQuestion10= new JLabel("Question 10: Event three:");
		lblQuestion10.setBounds(15, 376, 403, 20);
		contentPane.add(lblQuestion10);
		
		JComboBox Q10comboBox = new JComboBox();
		Q10comboBox.setModel(new DefaultComboBoxModel(new String[] {"","Very Hard", "Hard", "Neutural", "Easy", "Very Easy"}));
		Q10comboBox.setBounds(453,376, 128, 26);
		contentPane.add(Q10comboBox);
		
		JLabel lblQuestion11 = new JLabel("Question 11: Event four:");
		lblQuestion11.setBounds(15, 412, 403, 20);
		contentPane.add(lblQuestion11);
		
		JComboBox Q11comboBox = new JComboBox();
		Q11comboBox.setModel(new DefaultComboBoxModel(new String[] {"","None", "A little", "Average", "Quite a bit", "A lot"}));
		Q11comboBox.setBounds(453,412, 128, 26);
		contentPane.add(Q11comboBox);
		
		JLabel lblQuestion12 = new JLabel("Question 12: All subjects were taught in an understandable way. ");
		lblQuestion12.setBounds(15, 448, 403, 20);
		contentPane.add(lblQuestion12);
		
		JComboBox Q12comboBox = new JComboBox();
		Q12comboBox.setModel(new DefaultComboBoxModel(new String[] {"","None", "A little", "Average", "Quite a bit", "A lot"}));
		Q12comboBox.setBounds(453,448, 128, 26);
		contentPane.add(Q12comboBox);
		
		JLabel lblQuestion13 = new JLabel("Question 13: Has you interest in Computer Science changed after this event? ");
		lblQuestion13.setBounds(15, 484, 403, 20);
		contentPane.add(lblQuestion13);
		
		JComboBox Q13comboBox = new JComboBox();
		Q13comboBox.setModel(new DefaultComboBoxModel(new String[] {"","None", "A little", "Average", "Quite a bit", "A lot"}));
		Q13comboBox.setBounds(453,484, 128, 26);
		contentPane.add(Q13comboBox);
		
		JLabel lblQuestion14 = new JLabel("Question 14: How much did your interest change? ");
		lblQuestion14.setBounds(15, 520, 403, 20);
		contentPane.add(lblQuestion14);
		
		JComboBox Q14comboBox = new JComboBox();
		Q14comboBox.setModel(new DefaultComboBoxModel(new String[] {"","None", "A little", "Average", "Quite a bit", "A lot"}));
		Q14comboBox.setBounds(453,520, 128, 26);
		contentPane.add(Q14comboBox);
		
		JButton btnregister = new JButton("Submit Survey");
		btnregister.setHorizontalAlignment(SwingConstants.LEFT);
		btnregister.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				
			}
		});
		btnregister.setBounds(453, 582, 128, 29);
		contentPane.add(btnregister);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
			}
		});
		btnClear.setBounds(321, 582, 128, 29);
		contentPane.add(btnClear);
		
	}
}
