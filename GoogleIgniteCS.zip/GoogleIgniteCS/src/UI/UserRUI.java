package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Student;
import Classes.User;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class UserRUI extends JFrame 
{

	private JPanel contentPane;
	private JTextField FirstnameField;
	private JTextField LastnameField;
	private JTextField AgeField;
	private JTextField SetUsernameField;
	private JTextField SetusernameField2;
	private JPasswordField passwordField;
	private JPasswordField passwordField2;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					UserRUI frame = new UserRUI();
					frame.setVisible(true);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public UserRUI() {
		setTitle("Student Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 510);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFirstName = new JLabel("First Name:");
		lblFirstName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFirstName.setBounds(62, 16, 90, 20);
		contentPane.add(lblFirstName);
		
		FirstnameField = new JTextField();
		FirstnameField.setBounds(167, 13, 146, 26);
		contentPane.add(FirstnameField);
		FirstnameField.setColumns(10);
		
		//Warning error for empty fields
		
		
		JLabel lblLastName = new JLabel("Last Name: ");
		lblLastName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblLastName.setBounds(72, 55, 85, 20);
		contentPane.add(lblLastName);
		
		LastnameField = new JTextField();
		LastnameField.setBounds(167, 52, 146, 26);
		contentPane.add(LastnameField);
		LastnameField.setColumns(10);
		
		//Warning error for empty fields
		
		JLabel lblAge = new JLabel("Age: ");
		lblAge.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAge.setBounds(83, 91, 69, 20);
		contentPane.add(lblAge);
		
		AgeField = new JTextField();
		AgeField.setBounds(167, 88, 146, 26);
		contentPane.add(AgeField);
		AgeField.setColumns(10);
		
		//Warning error for empty fields
		
		JLabel lblGrade = new JLabel("Grade:");
		lblGrade.setHorizontalAlignment(SwingConstants.RIGHT);
		lblGrade.setBounds(83, 133, 69, 20);
		contentPane.add(lblGrade);
		
		JComboBox GradecomboBox = new JComboBox();
		GradecomboBox.setModel(new DefaultComboBoxModel(new String[] {"5", "6", "7", "8", "9", "10"}));
		GradecomboBox.setBounds(167, 130, 146, 26);
		contentPane.add(GradecomboBox);
		
		JLabel lblSetUserName = new JLabel("Set Username:");
		lblSetUserName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSetUserName.setBounds(43, 178, 111, 20);
		contentPane.add(lblSetUserName);
		
		SetUsernameField = new JTextField();
		SetUsernameField.setBounds(167, 172, 146, 26);
		contentPane.add(SetUsernameField);
		SetUsernameField.setColumns(10);
		
		//ADD Warning error for empty fields
		
		JLabel lblSetPassword = new JLabel("Set Password:");
		lblSetPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSetPassword.setBounds(41, 266, 111, 20);
		contentPane.add(lblSetPassword);
		
		JLabel lblNewLabel = new JLabel("Retype Username:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(17, 217, 135, 20);
		contentPane.add(lblNewLabel);
		
		//ADD Warning error for empty fields, and not matching usernames
		
		SetusernameField2 = new JTextField();
		SetusernameField2.setBounds(167, 214, 146, 26);
		contentPane.add(SetusernameField2);
		SetusernameField2.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(167, 263, 146, 26);
		contentPane.add(passwordField);
		
		JLabel lblRetypePassword = new JLabel("Retype Password:");
		lblRetypePassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRetypePassword.setBounds(12, 312, 140, 20);
		contentPane.add(lblRetypePassword);
		
		passwordField2 = new JPasswordField();
		passwordField2.setBounds(167, 309, 146, 26);
		contentPane.add(passwordField2);
		
		//ADD Warning error for empty fields/ none matching passwords
		
		
		
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				//main register, takes all inputs and assigns them to variabls that get stored to classes. 
				Student.setFirstName(FirstnameField.getText());
				Student.setLastName(LastnameField.getText());
				//Student.setAge(AgeField.getText()); //Convert to INT
				//Student.setGrade(GradecomboBox.getToolkit()); //converet to correct
				Student.setStudentUserName(SetusernameField2.getText());
				Student.setStudentPassword(passwordField2.getText());
				
				//testing class output
				try 
				{
					Registertest dialog = new Registertest();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception q) 
				{
					q.printStackTrace();
				}
				
				
				
				//takes user to survey
				try 
				{
					SurveyUI frame = new SurveyUI();
					frame.setVisible(true);
				} catch (Exception r) 
				{
					r.printStackTrace();
				}
			}
		});
		btnRegister.setBounds(198, 351, 115, 29);
		contentPane.add(btnRegister);
		
		
		//clears form
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				
				FirstnameField.setText("");
				LastnameField.setText("");
				AgeField.setText("");
				SetUsernameField.setText("");
				SetusernameField2.setText("");
				passwordField.setText("");
				passwordField2.setText("");
				
				
			}
		});
		btnClear.setBounds(198, 396, 115, 29);
		contentPane.add(btnClear);
		
		
		/*//red star warnings
		JLabel lblRequired = new JLabel("* required");
		lblRequired.setForeground(Color.RED);
		lblRequired.setBounds(15, 360, 98, 20);
		contentPane.add(lblRequired);
		
		JLabel label = new JLabel("*");
		label.setForeground(Color.RED);
		label.setBounds(15, 312, 17, 20);
		contentPane.add(label);
		*/
	}
}
