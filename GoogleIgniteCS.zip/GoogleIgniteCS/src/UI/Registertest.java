package UI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Student;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Registertest extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		try 
		{
			Registertest dialog = new Registertest();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}*/

	/**
	 * Create the dialog.
	 */
	public Registertest() 
	{
		setBounds(100, 100, 547, 543);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblFirstName = new JLabel("First Name: ");
		lblFirstName.setBounds(41, 33, 104, 20);
		contentPanel.add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Last Name:");
		lblLastName.setBounds(41, 69, 104, 20);
		contentPanel.add(lblLastName);
		
		JLabel lblAge = new JLabel("Age:");
		lblAge.setBounds(41, 105, 104, 20);
		contentPanel.add(lblAge);
		
		JLabel lblGrade = new JLabel("Grade: ");
		lblGrade.setBounds(41, 141, 104, 20);
		contentPanel.add(lblGrade);
		
		JLabel lblUserName = new JLabel("User Name: ");
		lblUserName.setBounds(41, 177, 104, 20);
		contentPanel.add(lblUserName);
		
		JLabel FNamelabel = new JLabel(""+Student.getFirstName());
		FNamelabel.setBounds(160, 33, 69, 20);
		contentPanel.add(FNamelabel);
		
		JLabel LNamelabel = new JLabel(""+Student.getLastName());
		LNamelabel.setBounds(160, 69, 69, 20);
		contentPanel.add(LNamelabel);
		
		JLabel AgeLabel = new JLabel(""+Student.getAge());
		AgeLabel.setBounds(160, 105, 69, 20);
		contentPanel.add(AgeLabel);
		
		JLabel Gradelabel = new JLabel(""+Student.getGrade());
		Gradelabel.setBounds(160, 141, 69, 20);
		contentPanel.add(Gradelabel);
		
		JLabel UserNameLabel = new JLabel(""+Student.getStudentUserName());
		UserNameLabel.setBounds(160, 177, 69, 20);
		contentPanel.add(UserNameLabel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() 
				{
					public void actionPerformed(ActionEvent e) 
					{
						
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
