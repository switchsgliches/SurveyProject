package UI;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class MainUI extends JFrame {

	private JPanel contentPane;
	private JTextField UserNametextField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainUI frame = new MainUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainUI() 
	{
		//Main Frame
		setTitle("Main UI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 290, 300);//frame dementions
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserName = new JLabel("User Name:");
		lblUserName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUserName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUserName.setBounds(15, 16, 100, 20);
		contentPane.add(lblUserName);
		
		UserNametextField = new JTextField();
		UserNametextField.setBounds(117, 13, 146, 26);
		contentPane.add(UserNametextField);
		UserNametextField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPassword.setBounds(25, 54, 88, 20);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(117, 52, 146, 26);
		contentPane.add(passwordField);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				UserNametextField.setText("");
				passwordField.setText("");
			}
		});
		btnClear.setBounds(0, 91, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				
			}
		});
		btnLogin.setBounds(148, 91, 115, 29);
		contentPane.add(btnLogin);
		
		JButton btnNewUser = new JButton("Student Register");
		btnNewUser.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					UserRUI frame = new UserRUI();
					frame.setVisible(true);
				} catch (Exception w) 
				{
					w.printStackTrace();
				}
			}
		});
		btnNewUser.setBounds(46, 154, 170, 29);
		contentPane.add(btnNewUser);
		
		JButton btnSurvey = new JButton("Survey");
		btnSurvey.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					SurveyUI frame = new SurveyUI();
					frame.setVisible(true);
				} catch (Exception r) 
				{
					r.printStackTrace();
				}
				
			}
		});
		btnSurvey.setBounds(72, 199, 115, 29);
		contentPane.add(btnSurvey);
	}
}
