package Classes;

public class User 
{
	public static String FirstName;
	public static String LastName;
	public static int Age;
	
	public User(String firstname, String lastname, int age)
	{
		FirstName = firstname;
		LastName = lastname;
		Age = age;
	}
	
	
	public User() 
	{
		// TODO Auto-generated constructor stub
	}


	public static void setFirstName(String Firstname)
	{
		FirstName = Firstname;
	}
	
	public static String getFirstName()
	{
		return FirstName ;
	}
	
	public static void setLastName(String Lastname)
	{
		LastName = Lastname;
	}
	
	public static String getLastName()
	{
		return LastName ;
	}
	
	public void setAge(int age)
	{
		this.Age = age;
	}
	
	public static int getAge()
	{
		return Age ;
	}
}