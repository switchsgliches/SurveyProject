package Classes;

public class Admin extends User
{
	private static int AdminId;
	private static String AdminName;
	private static String AdminPassword;
	
	public Admin()
	{
		
	}
	
	public Admin(String FirstName, String LastName,int ADid, String AdName, String Password, int Age)
	{
		super(FirstName, LastName, Age);
		Admin.setAdminId (ADid);
		Admin.setAdminName(AdName);
		this.setAdminPassword(Password);
	}
	
	public static int getAdminId()
	{
		return AdminId;
	}
	
	public static void setAdminId(int aDid) 
	{
		Admin.AdminId = aDid;
		
	}

	public static String getAdminName()
	{
		return AdminName;
	}

	public static void setAdminName(String adminName) 
	{
		Admin.AdminName = adminName;
	}

	public static String getAdminPassword() 
	{
		return AdminPassword;
	}

	public void setAdminPassword(String adminPassword) 
	{
		Admin.AdminPassword = adminPassword;
	}
}
