package Classes;

public class Student extends User
{
	private static String StudentUserName;
	private static String StudentPassword;
	private static String Grade;
	
	public Student()
	{
	}
	
	public Student(String FirstName, String LastName, String StName , String Password, int Age)
	{
		super(FirstName, LastName, Age);
		this.setStudentUserName(StName);
		this.setStudentPassword(Password);
	}
	
	public static String getStudentUserName()
	{
		return StudentUserName;
	}

	public static void setStudentPassword(String password) 
	{
		StudentPassword = password;
		
	}
	
	public String getStudentPassword()
	{
		return StudentPassword;
	}
	
	public static void setStudentUserName(String StName) 
	{
		StudentUserName = StName;
		
	}
	
	public static void setGrade(String grade)
	{
		Grade = grade;
	}
	
	public static String getGrade() 
	{
		
		return Grade;
	}
	
	public String toString()
	{
		return "" ;
	}

	

}
