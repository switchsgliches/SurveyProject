package survey;

import java.sql.SQLException;

public class Main 
{
	public static void main(String[] args) throws SQLException
	{
		// TODO Auto-generated method stub

		Menu Program = new Menu();
		Program.Start();

	
	}
}
