package survey;
public class Admin extends User
{
	private int AdminId;
	private String AdminName;
	private String AdminPassword;
	
	public Admin(String FirstName, String LastName,int ADid, String AdName, String Password, int Age)
	{
		super(FirstName, LastName, Age);
		this.setAdminId (ADid);
		this.setAdminName(AdName);
		this.setAdminPassword(Password);
	}
	
	public int getAdminId()
	{
		return AdminId;
	}
	
	private void setAdminId(int aDid) 
	{
		this.AdminId = aDid;
		
	}

	public String getAdminName()
	{
		return AdminName;
	}

	public void setAdminName(String adminName) 
	{
		this.AdminName = adminName;
	}

	public String getAdminPassword() 
	{
		return AdminPassword;
	}

	public void setAdminPassword(String adminPassword) 
	{
		this.AdminPassword = adminPassword;
	}
}
