/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package survey;

import java.util.Scanner;

public class Menu //used to hold Menu Methods 
{
	static Scanner input = new Scanner(System.in);
	
	public static void Start()
	{
		System.out.print("Welcome to the Google Ignite CS Survey.\n"
				+ "To start choose one of the following options.\n"
				+ "1: Register new account.\n"
				+ "2: Admin Login \n"
				+ "3: Student Login.\n"
				+ "4: Run Survey.\n"
				+ "5: Help.\n");
		
		int Function = input.nextInt();
		
		switch(Function)
		{
		case 1: Register.RegisterUser();
		break;
		case 2: Login.AdminLogin();
		break;
		case 3: Login.StudentLogin();
		break;
		case 4: Survey.Survey();
		break;
		case 5: Help();
		break;
		}
		
	}
	
	private static void Help()
	{
		System.out.println("If you are new, press 1 and 'Enter' to create your account");
		System.out.println("If you are an Admin, press 2 and 'Enter' to login");
		System.out.println("If you are a Student and already have an account, press 3 and 'Enter' to login");
		System.out.println("If you would like to run the Survey as a guest, press 4 and 'Enter'");
		Start();
	}

}
