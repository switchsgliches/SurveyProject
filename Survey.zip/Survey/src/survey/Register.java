
package survey;

import java.util.Scanner;

public class Register 
{
    static Student Person = new Student();
    public static void RegisterUser() 
	{
		Scanner input2 = new Scanner(System.in);
		
		
		
		System.out.println("New user registration.\n");
		
		System.out.println("Enter First Name.");
		String FName = input2.next();
		Person.setFirstName(FName);
		
		System.out.println("Enter Last Name.");
		String LName = input2.next();
		Person.setLastName(LName);
		
		System.out.println("Enter Age.");
		int age = input2.nextInt();
		Person.setAge(age);
		
		System.out.println("Enter your personal user name.");
		String Uname = input2.next();
		Person.setStudentName(Uname);
		
		System.out.println("Set a password. ");
		String StudentPass = input2.next();
		Person.setStudentPassword(StudentPass);
		
		System.out.println("Re Enter Password to confirm. ");
		String StudentPass2 = input2.next();
		if(StudentPass==StudentPass2)//confirms password set
		{
			Person.setStudentPassword(StudentPass);
			System.out.println("Password Set. ");
		}
		
		System.out.printf("Thank you. %s %s \n", Person.getFirstName(),Person.getLastName());
		
		System.out.print("");
		
		System.out.println("Would you like to take our survey now?\n"
				+ "Enter Y for yes, and N for No.");
		String Reply = input2.next();
		
		switch(Reply)
		{
		case "Y":
		case "y":  Survey.Survey();
		break;
		case "N":
		case "n": Menu.Start();
		}
		
	}
}
