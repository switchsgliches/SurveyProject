package survey;

import java.util.Scanner;

class Login 
{
    static Scanner input = new Scanner(System.in);
	private boolean StudentAuthentication = false;
	public String currentUserName;
        
        
        public static void StudentLogin() 
	{
		//StudentAuthentication = StudentManager.authenticateStudent(StudentName, StudentPassword);
		System.out.print("User Login.");
		System.out.print( "\nPlease enter your User Name: " );//prompt for user name
	    String UName = input.next(); // input user name 
	    if(UName == Register.Person.getStudentUserName())
	    System.out.print( "\nEnter your User Password: " ); // prompt for password
	    String UPass = input.next(); // input User Password
	    if(UPass == Register.Person.getStudentPassword())
	    {
	    	System.out.print("Login Succes");
	    }
	    else
	    {
	    	System.out.print("Login Error");
	    }
	}
        
        public static void AdminLogin() 
	{
		//AdminAuthentication = AdminManager.AuthenticateAdmin(AdminName, AdminPAssword);
		
        }
        private void UserLogin() 
	{
		System.out.print("User Login.");
		System.out.print( "\nPlease enter your User Name: " );//prompt for user name
	    String UName = input.next(); // input user name 
	    if(UName == Register.Person.getStudentUserName())
	    System.out.print( "\nEnter your User Password: " ); // prompt for password
	    String UPass = input.next(); // input User Password
	}
	
	private void authenticateStudent() 
	{
	      System.out.print( "\nPlease enter your User Name: " );//prompt for user name
	      String Username = input.next(); // input user name 
	      
	      System.out.print( "\nEnter your User Password: " ); // prompt for password
	      String Userpass = input.next(); // input User Password
	      
	      // set userAuthenticated to boolean value returned by database
	      //StudentAuthentication = StudentManager.authenticateUser( Username, Userpass );
	      
	      // check whether authentication succeeded
	      if ( StudentAuthentication )
	      {
	    	 //this.currentStudentName = Studentname; // save user's account
	    	  //System.out.print("!");
	      } // end if 
	      else
	      {
	         System.out.print( "Invalid User Name or Password. Please try again." );
	      }
	   	 
		} // end method authenticateUser
}
