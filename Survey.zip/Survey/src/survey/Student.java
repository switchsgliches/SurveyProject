package survey;
public class Student extends User
{
	private static String StudentUserName;
	private String StudentPassword;
	
	public Student()
	{
	}
	
	public Student(String FirstName, String LastName, String StName , String Password, int Age)
	{
		super(FirstName, LastName, Age);
		this.setStudentName(StName);
		this.setStudentPassword(Password);
	}
	
	public String getStudentUserName()
	{
		return StudentUserName;
	}

	void setStudentPassword(String password) 
	{
		this.StudentPassword = password;
		
	}
	
	public String getStudentPassword()
	{
		return StudentPassword;
	}
	
	void setStudentName(String StName) 
	{
		StudentUserName = StName;
		
	}
	
	public String toString()
	{
		return "" ;
	}

}
